package pack3;
import java.util.Scanner;
import pack0.Cricketers;
import pack1.Batsman;
import pack2.Bowler;


class Cricket
{
	
	public static void main(String args[])
	{
		Scanner sc1=new Scanner(System.in);
	String arr2[]={"Rishab Pant","Rohit Sharma","KL Rahul","Virat Kohli","Surya Kumar Yadav","Shreyas Iyer","Shikar Dhawan","Hardik Pandya","Ajinkya Rahane","MS Dhoni"};
	int arr1[]={24,34,29,33,31,27,36,28,33,40};
	int Matches_Played[]={24,230,42,260,7,26,149,63,90,350};
	int Innings_Played[]={22,223,41,251,7,24,146,46,87,297};
	int Total_Runs[]={715,9283,1634,12311,267,947,6284,1286,2962,10773};
	int Half_Centuries[]={5,44,10,64,2,9,35,7,24,73};
	int Centuries[]={0,29,5,43,0,1,17,0,3,10};
	int Bowls_Faced[]={654,10427,1844,13249,259,986,6730,1099,3767,12303};
	int Notouts[]={0,32,6,39,2,1,8,7,3,84};
	
	String arr[]={"Jasprit Bumrah","R Ashwin","Bhuvaneshwar Kumar","R Jadeja","Y Chahal","Umesh Yadav","Shardul Thakur","Kuldeep Yadav","Md Shami"};
	int age1[]={28,35,32,33,31,34,30,27,31};
	int matches_played[]={70,113,121,168,61,75,19,66,79};
	int wickets1[]={123,151,141,188,104,106,25,109,148};
	double average1[]={21.7,33.5,35.1,37.4,25.3,33.6,40.2,28.3,25.6};
	
	
	//String y1[]=new String[arr2.length];
	//String y2[]=new String[arr.length];
	System.out.println("Press 1 for Batsman ");
		System.out.println("Press 2 for Bowler ");
		int e =sc1.nextInt();
	if (e == 1)
	{
	for(int i=0;i<arr2.length;i++)
		{
		Batsman a=new Batsman(arr2[i],arr1[i],Matches_Played[i],Total_Runs[i],Half_Centuries[i],Centuries[i],Bowls_Faced[i],Notouts[i],Innings_Played[i]);
		a.Details();
		}
		Batsman a=new Batsman();
		a.m2();
	}
	else if (e == 2)
	{
		for(int i=0;i<arr.length;i++)
		{
		Bowler b1=new Bowler(arr[i],age1[i],matches_played[i],wickets1[i],average1[i]);
		b1.Details();
		}
		Bowler b=new Bowler();
			b.m2();
	}
		else 
		{
			System.out.println("Invalid");
		}		
	}
}




	
	
		
	
	