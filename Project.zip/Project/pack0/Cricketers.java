package pack0;
public interface Cricketers
{
	public void Details();
}