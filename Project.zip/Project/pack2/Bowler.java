package pack2;
import pack0.Cricketers;
//import pack1.Batsman;
import java.util.*;

public class Bowler implements Cricketers
{
	Scanner sc=new Scanner(System.in);
	static int l=0;
	String name;
	int age;
	double average;
	int matches;
	int wickets;
	static String z[]=new String[10];
	static int age1[]=new int[10];
	static int matches_played[]=new int[10];
	static int wickets1[]=new int[10];
	static double average1[]=new double[10];
	
	static
	{
		System.out.println(" \t \t ===================    Category : Bowlers    ===================");
		System.out.println(" \t \t    ===================    Players Name    ===================");
	}
	
	
	public Bowler(String name,int age1,int matches_played,int wickets1, double average1)
	{
	/*	this.age=age1;
		this.average=average;
		this.matches=matches;
		this.wickets=wickets;
		
	*/	
		for(int e=this.l;e<10;e++){
		
		this.z[l]=name;
		this.age1[l]=age1;
		this.average1[l]=average1;
		this.matches_played[l]=matches;
		this.wickets1[l]=wickets1;
		this.matches_played[l]=matches_played;
		++l;
		break;
		}		
	}
	
	public Bowler(){}
	@Override
	public void Details(){

		System.out.println(z[l-1]);	
	}
	
	
	
	public void m2(){
		while(true){
		 System.out.println();
		System.out.println("Enter name of the player whose stats are to be shown or Press '0' to exit");
	switch(sc.nextLine()){
		case "Jasprit Bumrah" :
			                System.out.println(" Player Name \t: "+z[0]+"\n age \t\t: "+age1[0]+"\n Matches \t: "+matches_played[0]+"\n wickets \t: "+wickets1[0]+"\n Average \t: "+average1[0] );
			break;
		case "R Ashwin" :
			                System.out.println(" Player Name \t: "+z[1]+"\n age \t\t: "+age1[1]+"\n Matches \t: "+matches_played[1]+"\n wickets \t: "+wickets1[1]+"\n Average \t: "+average1[1] );
			break;
		case "Bhuvaneshwar Kumar" :
			                System.out.println(" Player Name \t: "+z[2]+"\n age \t\t: "+age1[2]+"\n Matches \t: "+matches_played[2]+"\n wickets \t: "+wickets1[2]+"\n Average \t: "+average1[2] );
			break;
		case "R Jadeja" :
							System.out.println(" Player Name \t: "+z[3]+"\n age \t\t: "+age1[3]+"\n Matches \t: "+matches_played[3]+"\n wickets \t: "+wickets1[3]+"\n Average \t: "+average1[3] );
			break;
		case "Y Chahal" :
							System.out.println(" Player Name \t: "+z[4]+"\n age \t\t: "+age1[4]+"\n Matches \t: "+matches_played[4]+"\n wickets \t: "+wickets1[4]+"\n Average \t: "+average1[4] );
			break;
		case "Umesh Yadav" :
							System.out.println(" Player Name \t: "+z[5]+"\n age \t\t: "+age1[5]+"\n Matches \t: "+matches_played[5]+"\n wickets \t: "+wickets1[5]+"\n Average \t: "+average1[5] );
			break;
		case "Shardul Thakur" :
							System.out.println(" Player Name \t: "+z[6]+"\n age \t\t: "+age1[6]+"\n Matches \t: "+matches_played[6]+"\n wickets \t: "+wickets1[6]+"\n Average \t: "+average1[6] );
			break;
		case "Kuldeep Yadav" :
							System.out.println(" Player Name \t: "+z[7]+"\n age \t\t: "+age1[7]+"\n Matches \t: "+matches_played[7]+"\n wickets \t:"+wickets1[7]+"\n Average \t: "+average1[7] );
			break;
		case "Md Shami" :
							System.out.println(" Player Name \t: "+z[8]+"\n age \t\t: "+age1[8]+"\n Matches \t: "+matches_played[8]+"\n wickets \t:"+wickets1[8]+"\n Average \t: "+average1[8] );
			break;
		case "0" :
			System.exit(0);
		default :
							System.out.println("Entered name didnot Match any player, Please try again..............");
	}
	}	
	}
	
}

