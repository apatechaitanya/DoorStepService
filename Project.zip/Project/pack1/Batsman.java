package pack1;
import pack0.Cricketers;
import java.util.*;
import java.util.Arrays;

 public class Batsman implements Cricketers
{
	Scanner sc=new Scanner(System.in);
	static int l=0;
	int Matches_Played;
	static String name[]=new String[10];
	static int age[]=new int[10];
	static int Matches_Played1[]=new int[10];
	static int Innings_Played[]=new int[10];
	static int Total_Runs[]=new int[10];
	static int Half_Centuries[]=new int[10];
	static int Centuries[]=new int[10];
	static int Bowls_Faced[]=new int[10];
	static int Notouts[]=new int[10];
	
	 static
	{
		System.out.println("\t \t~~~~~~~~~~~~~~~~~~Category : Batsman~~~~~~~~~~~~~~~");
		System.out.println("\t \t~~~~~~~~~~~~~~~~~~~~~Players Name~~~~~~~~~~~~~~~~~~~~~~");
	}
	
	
	public Batsman(String name,int age,int Matches_Played,int Total_Runs,int Half_Centuries,int Centuries,int Bowls_Faced,int Notouts,int Innings_Played)
	{
		//this.age=age;
		for(int e=this.l;e<10;e++){
		
		this.name[l]=name;
		this.age[l]=age;
		this.Matches_Played1[l]=Matches_Played;
		this.Total_Runs[l]=Total_Runs;
		this.Half_Centuries[l]=Half_Centuries;
		this.Centuries[l]=Centuries;
		this.Bowls_Faced[l]=Bowls_Faced;
		this.Notouts[l]=Notouts;
		this.Innings_Played[l]=Innings_Played;
		++l;
		break;
		}		
	}
	
	public Batsman(){}
	@Override
	public void Details(){

		System.out.println(name[l-1]);	
	}
	
	
	public void m2(){
		while(true){
		 System.out.println();
		System.out.println("Enter name of the player whose stats are to be shown or Press '0' to exit");
	switch(sc.nextLine()){
			case "Rishab Pant" :
			System.out.println(" Player Name \t: "+name[0]+"\n age \t\t: "+age[0]+"\n Matches \t: "+Matches_Played1[0]+"\n Runs \t\t: "+Total_Runs[0]+"\n HalfCenturies \t: "+Half_Centuries[0]+"\n Centuries \t: "+Centuries[0]+"\n Strike Rate \t: "+(((float)100*Total_Runs[0])/Bowls_Faced[0])+"\n Average \t: "+((float)Total_Runs[0])/(Innings_Played[0]-Notouts[0]) );
			break;
			case "Rohit Sharma" :
			System.out.println(" Player Name \t: "+name[1]+"\n age \t\t: "+age[1]+"\n Matches \t: "+Matches_Played1[1]+"\n Runs \t\t: "+Total_Runs[1]+"\n HalfCenturies \t: "+Half_Centuries[1]+"\n Centuries \t: "+Centuries[1]+"\n Strike Rate \t: "+(((float)100*Total_Runs[1])/Bowls_Faced[1])+"\n Average \t: "+((float)Total_Runs[1])/(Innings_Played[1]-Notouts[1])  );
			break;
			case "KL Rahul" :
			System.out.println(" Player Name \t: "+name[2]+"\n age \t\t: "+age[2]+"\n Matches \t: "+Matches_Played1[2]+"\n Runs \t\t: "+Total_Runs[2]+"\n HalfCenturies \t: "+Half_Centuries[2]+"\n Centuries \t: "+Centuries[2]+"\n Strike Rate \t: "+(((float)100*Total_Runs[2])/Bowls_Faced[2])+"\n Average \t: "+((float)Total_Runs[2])/(Innings_Played[2]-Notouts[2])  );
			break;
			case "Virat Kohli" :
			System.out.println(" Player Name \t: "+name[3]+"\n age \t\t: "+age[3]+"\n Matches \t: "+Matches_Played1[3]+"\n Runs \t\t: "+Total_Runs[3]+"\n HalfCenturies \t: "+Half_Centuries[3]+"\n Centuries \t: "+Centuries[3]+"\n Strike Rate \t: "+(((float)100*Total_Runs[3])/Bowls_Faced[3])+"\n Average \t: "+((float)Total_Runs[3])/(Innings_Played[3]-Notouts[3])  );
			break;
			case "Surya Kumar Yadav" :
			System.out.println(" Player Name \t: "+name[4]+"\n age \t\t: "+age[4]+"\n Matches \t: "+Matches_Played1[4]+"\n Runs \t\t: "+Total_Runs[4]+"\n HalfCenturies \t: "+Half_Centuries[4]+"\n Centuries \t: "+Centuries[4]+"\n Strike Rate \t: "+(((float)100*Total_Runs[4])/Bowls_Faced[4])+"\n Average \t: "+((float)Total_Runs[4])/(Innings_Played[4]-Notouts[4])  );
			break;
			case "Shreyas Iyer" :
			System.out.println(" Player Name \t: "+name[5]+"\n age \t\t: "+age[5]+"\n Matches \t: "+Matches_Played1[5]+"\n Runs \t\t: "+Total_Runs[5]+"\n HalfCenturies \t: "+Half_Centuries[5]+"\n Centuries \t: "+Centuries[5]+"\n Strike Rate \t: "+(((float)100*Total_Runs[5])/Bowls_Faced[5])+"\n Average \t: "+((float)Total_Runs[5])/(Innings_Played[5]-Notouts[5])  );
			break;
			case "Shikar Dhawan" :
			System.out.println(" Player Name \t: "+name[6]+"\n age \t\t: "+age[6]+"\n Matches \t: "+Matches_Played1[6]+"\n Runs \t\t: "+Total_Runs[6]+"\n HalfCenturies \t: "+Half_Centuries[6]+"\n Centuries \t: "+Centuries[6]+"\n Strike Rate \t: "+(((float)100*Total_Runs[6])/Bowls_Faced[6])+"\n Average \t: "+((float)Total_Runs[6])/(Innings_Played[6]-Notouts[6])  );
			break;
			case "Hardik Pandya" :
			System.out.println(" Player Name \t: "+name[7]+"\n age \t\t: "+age[7]+"\n Matches \t: "+Matches_Played1[7]+"\n Runs \t\t: "+Total_Runs[7]+"\n HalfCenturies \t: "+Half_Centuries[7]+"\n Centuries \t: "+Centuries[7]+"\n Strike Rate \t: "+(((float)100*Total_Runs[7])/Bowls_Faced[7])+"\n Average \t: "+((float)Total_Runs[7])/(Innings_Played[7]-Notouts[7])  );
			break;
			case "Ajinkya Rahane" : 
			System.out.println(" Player Name \t: "+name[8]+"\n age \t\t: "+age[8]+"\n Matches \t: "+Matches_Played1[8]+"\n Runs \t\t: "+Total_Runs[8]+"\n HalfCenturies \t: "+Half_Centuries[8]+"\n Centuries \t: "+Centuries[8]+"\n Strike Rate \t: "+(((float)100*Total_Runs[8])/Bowls_Faced[8])+"\n Average \t: "+((float)Total_Runs[8])/(Innings_Played[8]-Notouts[8])  );
			break;
			case "MS Dhoni" :
			System.out.println(" Player Name \t: "+name[9]+"\n age \t\t: "+age[9]+"\n Matches \t: "+Matches_Played1[9]+"\n Runs \t\t: "+Total_Runs[9]+"\n HalfCenturies \t: "+Half_Centuries[9]+"\n Centuries \t: "+Centuries[9]+"\n Strike Rate \t: "+(((float)100*Total_Runs[9])/Bowls_Faced[9])+"\n Average \t: "+((float)Total_Runs[9])/(Innings_Played[9]-Notouts[9])  );
			break;
			case "0" :
			System.exit(0);
			default :
			System.out.println("\n .....Entered name didnot Match any player, Please try again..............");
	}	
	}
	}
	
}


